import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
//        int age = 21;
//        double gpa = 3.5;
//        char grade = 'A';
//        boolean passed = true;
//        String name = "shabeer inayat";
//
//        System.out.println("Name: " + name);
//        System.out.println("Age: " + age);
//        System.out.println("GPA: " + gpa);
//        System.out.println("Grade: " + grade);
//        System.out.println("Passed: " + passed);
//
//                Scanner sc = new Scanner(System.in);
//                System.out.print("Enter first number: ");
//                int a = sc.nextInt();
//                System.out.print("Enter second number: ");
//                int b = sc.nextInt();
//                System.out.println("Sum = " + (a + b));
//        int num = 7;
//
//        if (num > 0) {
//            System.out.println("Positive");
//        } else if (num < 0) {
//            System.out.println("Negative");
//        } else {
//            System.out.println("Zero");
//        }
//        }
//        int[] marks = {65, 50, 78, 93, 98};
//
//        int sum = 0;
//        for (int i = 0; i < marks.length; i++) {
//            sum += marks[i];
//        }
//
//        double average = (double) sum / marks.length;
//        System.out.println("Average Marks = " + average);
//
//        System.out.println("Factorial = " + factorial(5));
//    }
//
//    public static int factorial(int n) {
//        int fact = 1;
//        for (int i = 1; i <= n; i++) {
//            fact *= i;
//        }
//        return fact;
//        class Car {
//            String brand;
//            String model;
//            double price;
//
//            Car(String b, String m, double p) {
//                brand = b;
//                model = m;
//                price = p;
//            }
//
//            void displayDetails() {
//                System.out.println("Brand: " + brand + ", Model: " + model + ", Price: $" + price);
//            }
//        }
//
//            Car c1 = new Car("Toyota", "century", 28600);
//            Car c2 = new Car("Honda", "reborn", 31000);
//            c1.displayDetails();
//            c2.displayDetails();
//

      }
}



